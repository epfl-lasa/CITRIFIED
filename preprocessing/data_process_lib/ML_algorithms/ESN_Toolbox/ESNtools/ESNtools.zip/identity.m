function result = identity(input)
% IDENTITY just returns its input. 
% result <- input
% it is needed when the activation function is linear while calling
% feval(.)

% Created April 30, 2006, D. Popovici
% Copyright: Fraunhofer IAIS 2006 / Patent pending

result = input ; 
  
